/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.time.LocalDate;

/**
 *
 * @author p001495
 */
public class FuncionarioModel {
    
    private String cpf;
    private String nome;
    private String diaNascimento;
    private String mesNascimento;
    private String anoNascimento;

    public FuncionarioModel(String cpf, String nome, String diaNascimento) {
        this.cpf = cpf;
        this.nome = nome;
        this.diaNascimento = diaNascimento;
    }

    public FuncionarioModel() {
    }
    
    
    
    
    

    public String getCpf() {
        return cpf;
    }

    public String getNome() {
        return nome;
    }

    public String getDiaNascimento() {
        return diaNascimento;
    }

    public String getMesNascimento() {
        return mesNascimento;
    }

    public String getAnoNascimento() {
        return anoNascimento;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public void setDiaNascimento(String diaNascimento) {
        this.diaNascimento = diaNascimento;
    }

    public void setMesNascimento(String mesNascimento) {
        this.mesNascimento = mesNascimento;
    }

    public void setAnoNascimento(String anoNascimento) {
        this.anoNascimento = anoNascimento;
    }

    @Override
    public String toString() {
        return this.nome; //To change body of generated methods, choose Tools | Templates.
    }
    
    
    
    
    
    
    
    
    
}
