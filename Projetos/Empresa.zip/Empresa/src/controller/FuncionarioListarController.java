/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import dao.FuncionarioDAO;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.Vector;
import javax.swing.table.DefaultTableModel;
import model.FuncionarioModel;
import view.TelaListarFuncionariosCadastrados;

/**
 *
 * @author p001495
 */
public class FuncionarioListarController {
    
     TelaListarFuncionariosCadastrados view;
    Vector<FuncionarioModel> listaFuncionarios;
        
    public FuncionarioListarController(TelaListarFuncionariosCadastrados view){
        this.view = view;        
        view.addBtnListarFuncionariosListener(new ListarFuncionariosListener());
        view.setVisible(true);
    }
    
    class ListarFuncionariosListener implements ActionListener{
        @Override
        public void actionPerformed(ActionEvent e) {
            System.out.println("Fui clicado");
            String  valorBuscado = view.getJtftextoBuscado();
            
            FuncionarioDAO dao = new FuncionarioDAO();
            listaFuncionarios = dao.listar(valorBuscado);
            
            Vector conjuntoLinhas = new Vector();
        
            for(FuncionarioModel funcionario: listaFuncionarios){
                Vector linha = new Vector();
            
                linha.add(funcionario.getCpf());
                linha.add(funcionario.getNome());
                linha.add(funcionario.getDiaNascimento());
                conjuntoLinhas.add(linha);
            }
        
            Vector conjuntoColunas = new Vector();
            conjuntoColunas.add("CPF"); 
            conjuntoColunas.add("Nome");
            conjuntoColunas.add("Dia do Nascimento");
            
            DefaultTableModel modeloTabela = 
                    new DefaultTableModel(conjuntoLinhas, conjuntoColunas);
            view.setJtfuncionariosCadastrados(modeloTabela);
        }       
    }
    
     
}
