/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import dao.FuncionarioDAO;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import model.FuncionarioModel;
import view.TelaCadastraFuncionario;

/**
 *
 * @author p001495
 */
public class FuncionarioController {
    
    TelaCadastraFuncionario view = new TelaCadastraFuncionario();

    public FuncionarioController(TelaCadastraFuncionario view) {
        System.out.println("Cheguei no controller");
        this.view = view;
        view.addBtnCadastrarFuncionarioListener(new CadastrarFuncionarioListener());
        view.setVisible(true);
    }
    
    class CadastrarFuncionarioListener implements ActionListener{
        
        @Override
        public void actionPerformed(ActionEvent e) {
            System.out.println("Fui clicado");
            String  cpf = view.getJtfcpf();
            String  nome = view.getJtfnome();
            String dia = view.getJtfdianascimento();
            String mes = view.getJtfmesnascimento();
            String ano = view.getJtfanonascimento();
            
            //camada modelo
            FuncionarioModel funcionario = new FuncionarioModel();
            funcionario.setCpf(cpf);
            funcionario.setNome(nome);
            funcionario.setDiaNascimento(dia);
            funcionario.setMesNascimento(mes);
            funcionario.setAnoNascimento(ano);
            FuncionarioDAO dao = new FuncionarioDAO();
            
            
            
            
            try {
                if(dao.cadastrar(funcionario)){
                    view.showMessage("Cadastro realizado com sucesso");
                }else{
                    view.showMessage("Cadastro não realizado!!");
                }
            } catch (SQLException ex) {
                Logger.getLogger(FuncionarioController.class.getName()).log(Level.SEVERE, null, ex);
            }
        }       
    }
    
    
    
}
