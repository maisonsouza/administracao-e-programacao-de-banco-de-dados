/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mvc;

import controller.FuncionarioListarController;
import view.TelaListarFuncionariosCadastrados;

/**
 *
 * @author p001495
 */
public class RunListarFuncionariosCadastrados {
    
    public static void main(String[] args) {
        TelaListarFuncionariosCadastrados telalistarfuncionario = new TelaListarFuncionariosCadastrados();
        FuncionarioListarController controller = new FuncionarioListarController(telalistarfuncionario);
    }
    
}
