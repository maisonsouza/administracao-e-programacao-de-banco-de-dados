/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import connection.FabricaConexao;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Vector;
import model.FuncionarioModel;

/**
 *
 * @author p001495
 */
public class FuncionarioDAO {

    private final Connection connection;

    public FuncionarioDAO() {
        this.connection = FabricaConexao.getConnection();
    }
    
    

    public boolean cadastrar(FuncionarioModel funcionario) throws SQLException {

        try {
            Connection con = FabricaConexao.getConnection();
            CallableStatement stmt = con.prepareCall("{call sp_InserirFuncionario(?, ?, ?,?,?)}");
            stmt.setString(1, funcionario.getCpf());
            stmt.setString(2, funcionario.getNome());
            stmt.setString(3, funcionario.getDiaNascimento());
            stmt.setString(4, funcionario.getMesNascimento());
            stmt.setString(5, funcionario.getAnoNascimento());
            stmt.execute();
            stmt.close();
            connection.close();
            return true;
        } catch (SQLException ex) {
            throw new RuntimeException(ex.getMessage());
        }

    }

    /**
     *
     * @param valorBuscado
     * @return
     */
    public Vector<FuncionarioModel> listar(String valorBuscado) {
        System.out.println("Entrei no métdo DAO");
        String sql = "SELECT * FROM funcionario f WHERE f.cpf LIKE ? ";
        try {
            PreparedStatement ps = connection.prepareStatement(sql);
            ps.setString(1, '%' + valorBuscado + '%');
            ResultSet rs = ps.executeQuery();
            Vector<FuncionarioModel> listaFuncionarios = new Vector();
            while (rs.next()) {
                String cpf = rs.getString("cpf");
                /**
                 * nome do campo no BD *
                 */
                String nome = rs.getString("nome");
                String diaDoNascimento = rs.getString("diaNasc");
                FuncionarioModel funcionario = new FuncionarioModel(cpf, nome, diaDoNascimento);
                listaFuncionarios.add(funcionario);
            }
            ps.close();
            connection.close();
            return listaFuncionarios;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public boolean alterar(FuncionarioModel curso) {
        String sql = "UPDATE CURSO SET sigla=?, descricao=? WHERE idCurso=?";
        try {
            PreparedStatement ps = connection.prepareStatement(sql);
            ps.setString(1, curso.getSigla());
            ps.setString(2, curso.getDescricao());
            ps.setInt(3, curso.getIdCurso());
            ps.execute();
            connection.close();
            return true;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public boolean excluir(int idCurso) {
        String sql = "DELETE FROM CURSO WHERE idCurso=?";
        try {
            PreparedStatement ps = connection.prepareStatement(sql);
            ps.setInt(1, idCurso);
            ps.execute();
            connection.close();
            return true;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

}
