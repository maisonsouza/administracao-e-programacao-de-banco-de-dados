/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package connection;

import java.sql.Connection;
import java.sql.SQLException;

/**
 *
 * @author p001495
 */
public class TestaConexao {
    
    public static void main(String[] args) throws SQLException {
        System.out.println("Testando a conexão com o banco de dados");
        Connection con = FabricaConexao.getConnection();
        if(con != null){
            System.out.println("Conexão estabelecida com = "+con.getCatalog());
        }
    }
    
}
